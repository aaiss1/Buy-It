import json

import certifi
import paho.mqtt.client as mqtt
import argparse
import time
import requests

parser = argparse.ArgumentParser()
parser.add_argument("-e", "--endpoint", action="store", required=True, dest="host", help="Your Solace IoT endpoint")
parser.add_argument("-u", "--username", action="store", required=True, dest="username", help="Your Solace IoT username")
parser.add_argument("-p", "--password", action="store", required=True, dest="password", help="Your Solace IoT password")

args = parser.parse_args()
host = args.host
username = args.username
password = args.password

# Callback on connection
def on_connect(client, userdata, flags, rc):
    print(f'Connected (Result: {rc})')
    client.subscribe(f'iot/{username}/product')


# Callback when message is received
def on_message(client, userdata, msg):
    itemname = msg.payload.decode("ascii")
    print(f'ItemName: {itemname}')
    params = {
        "api_key": "tMNiNEg2BHmX",
        "start_url": "https://ca.camelcamelcamel.com/",
        "start_template": "main_template",
        "start_value_override": "{\"keywords\": [\"" + itemname + "\"]}",
        "send_email": "0"
    }
    time.sleep(1)
    r = requests.post("https://www.parsehub.com/api/v2/projects/tCuBbDSFZNDD/run", data=params)
    r = r.json()
    run_token = r['run_token']
    print('https://www.parsehub.com/api/v2/runs/' + run_token + '/data')

    params2 = {
        "api_key": "tMNiNEg2BHmX"
    }

    status = 'initialized'
    while status == 'initialized' or status == 'queued' or status == 'running':
        params3 = {
            "api_key": "tMNiNEg2BHmX"
        }
        time.sleep(1)
        r3 = requests.get('https://www.parsehub.com/api/v2/runs/' + run_token, params=params3)
        r3 = r3.json()
        status = r3['status']
        print(r3['status'])

    if r3['data_ready'] == True:
        time.sleep(2)
        r2 = requests.get('https://www.parsehub.com/api/v2/runs/' + run_token + '/data', params=params2)

    client.publish(f'iot/{username}/' + itemname, payload=json.dumps(r2.json()))

    client.loop_stop()


client = mqtt.Client()

client.on_connect = on_connect
client.on_message = on_message
client.tls_set(ca_certs=certifi.where())
client.username_pw_set(username, password)
client.connect(host, port=8883)

client.subscribe('iot/{username}/product')
searchTerm = "1"

client.loop_start()

while True:
    time.sleep(1.0)

# while True:
#     searchTerm = client.on_message.msg
#     print(searchTerm)
#     time.sleep(1)

############################################################################################